import {VueMasonryPlugin} from './src/masonry.plugin.js'

export default VueMasonryPlugin

export { VueMasonryPlugin }
